# IoTCOM Security Verification -- 

To open the files in this folder, run Alloy and open any of the ''bundle_N_Fig_X.als'' files:

  * bundle_1_Fig_8.als: this bundle represents the case study illustrated in Fig 8.
  * bundle_2_Fig_7.als: this bundle represents the case study illustrated in Fig 7.
  * bundle_3_Fig_6.als: this bundle represents the case study illustrated in Fig 6.


